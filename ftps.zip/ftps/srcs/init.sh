#!/bin/sh

sudo mkdir /srv/ftp
sudo chown nobody:nogroup /srv/ftp
echo "anon" | sudo tee /srv/ftp/anon.txt

adduser -D -h /srv/ftp mhenry
echo "mhenry:pw" | chpasswd

openrc
touch run/openrc/softlevel
rc-service vsftpd start
rc-update add vsftpd default
rc-service vsftpd restart

/bin/sh